import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders }    from '@angular/common/http';
 
import { from, Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

 

@Injectable({
  providedIn: 'root'
})
export class ServiceService {



constructor(private http: HttpClient) { }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }  
  getData(){
    return this.http.get("https://tasksmanager-302f5.firebaseio.com/Task.json");
    
  }

  postData(formData){
   
    return this.http.post("https://tasksmanager-302f5.firebaseio.com/Task.json",formData);
  }

  putData(name,formData){

    let url = 'https://tasksmanager-302f5.firebaseio.com/Task/' + name+'.json'
   return this.http.put(url,formData);
    
  }
  deleteData(name){
    let url = 'https://tasksmanager-302f5.firebaseio.com/Task/' + name+'.json'
    return this.http.delete(url);
  }
  
}
