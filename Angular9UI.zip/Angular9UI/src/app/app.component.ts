import { Component } from '@angular/core';
import {ServiceService} from './service.service';
import { FormGroup, FormControl,Validators } from '@angular/forms'; 
import { MatDialog } from '@angular/material/dialog';

import { element } from 'protractor';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Technical Interview';

  constructor(private ServiceService: ServiceService,public dialog: MatDialog) { }
  data: any;
  scheduleTask: FormGroup;
  submitted = false; 
  EventValue: any = "Save";
   products : any[ ];

   imageload : any;
   displayElement :boolean;
   addEdit :boolean;

  ngOnInit(): void {
    this.imageload = ".\src\assets\Images";

    this.displayElement = false;
    this.getdata();
    this.addEdit = true;

    this.scheduleTask = new FormGroup({
      id: new FormControl(null),
      jsonvalue : new FormControl(null),
      description: new FormControl("",[Validators.required]),      
      priority: new FormControl("",[Validators.required]),
      status:new FormControl("",[Validators.required]),
       
    })  
  }
  getdata() {
    this.ServiceService.getData( ).subscribe((data : any) => {
      debugger;
   var data = data;
      let product =[];
      let productvalue=[];
      let value1: any ;
      let value2: any;
      let value3: any;
      let value4: any;

      var people = Object.keys(data );

      if( people != null){
      people.forEach(function(products) {

        if (products.indexOf('-') > -1) {

        debugger;
        var items = Object.keys( data [products]);
        debugger;
        items.forEach(function(item,key) {
          debugger;
          if(item=="description"){
           value1 = data [products][item];
          }
          if(item=="id"){
            value2 = data [products][item];
            }
            if(item=="priority"){
               value3 = data [products][item];
              }
              if(item=="status"){
                 value4 = data [products][item];
                }
                
        });
        debugger;
        product.push({ "jsonvalue":products,"description":value1 , "id":value2, "priority":value3 , "status":value4 }) 
        debugger;
      }
      
    });
    }

     this.products = product;
       
    })
  }
  
  deleteData(data: any) {
    this.displayElement= false;
    this.ServiceService.deleteData(data.jsonvalue).subscribe((data: any[]) => {
     alert("Data is deleted successfully")
      this.getdata();
    })
    this.addEdit = true;
  }
  Save() { 
    this.submitted = true;
  
     if (this.scheduleTask.invalid) {
            return;
     }

    this.ServiceService.postData(this.scheduleTask.value).subscribe((data: any[]) => {
      alert("Data is Saved successfully")
      this.getdata();
      this.resetFrom();
      this.addEdit = true;
      this.displayElement= false;

    })
  }
  Update() { 
    this.displayElement = true;
    this.submitted = true;
  
    if (this.scheduleTask.invalid) {
     return;
    }      

    debugger;

    let jsonName = this.scheduleTask.value.jsonvalue;
   
    this.scheduleTask.removeControl('jsonvalue'); 
debugger;
    this.ServiceService.putData(jsonName,this.scheduleTask.value).subscribe((data: any[]) => {
      alert("Data is Updated successfully")
      this.resetFrom();
    })
    this.addEdit = true;
    this.displayElement= true;

  }

  EditData(Data: { id: any; description: any; priority: any; status: any; jsonvalue: any   }) {
    this.displayElement =true;
    this.scheduleTask.controls["id"].setValue(Data.id);
    this.scheduleTask.controls["description"].setValue(Data.description);    
    this.scheduleTask.controls["priority"].setValue(Data.priority);
    this.scheduleTask.controls["status"].setValue(Data.status);
    this.scheduleTask.controls["jsonvalue"].setValue(Data.jsonvalue);
    this.EventValue = "Update";
    this.displayElement= true;
    this.addEdit = false;
  }

  resetFrom(){   
    debugger;
    this.displayElement= true;
    this.getdata();
    this.scheduleTask.reset();
    this.EventValue = "Save";
    this.submitted = false; 
  }
  
  navigation(){
    this.addEdit = true;
    this.displayElement= false;
  }


}
